/*package com.pyr0r4t.photona.client.mixin;


import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.RenderType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(RenderType.class)
public interface RenderTypeInvoker {

    // We target Mojang's private static "create" factory method.
    // We change the return type to base RenderType, and the final state parameter to Object.
    @Invoker("create")
    static RenderType invokeCreate(
            String name,
            VertexFormat format,
            VertexFormat.Mode mode,
            int bufferSize,
            boolean affectsCrumbling,
            boolean sortOnUpload,
            Object compositeState
    ) {
        throw new UnsupportedOperationException();
    }
}*/
