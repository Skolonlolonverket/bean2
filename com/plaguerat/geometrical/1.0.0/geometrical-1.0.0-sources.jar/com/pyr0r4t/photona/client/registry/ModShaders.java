package com.pyr0r4t.photona.client.registry;

import net.minecraft.class_5944;

public class ModShaders {
    public static class_5944 MAGMA_BLOOM_SHADER;
}
