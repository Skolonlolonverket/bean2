package com.pyr0r4t.photona.lights;

import net.minecraft.class_1162;

public class Material {

    private class_1162 ambientColour, diffuseColour, specularColour;
    private float reflectance;
    // Texture texture;
    public static final class_1162 color = new class_1162(1.0f, 1.0f, 1.0f, 1.0f);

    public Material() {
        this.ambientColour=color;
        this.diffuseColour=color;
        this.specularColour=color;
    }

    public Material(class_1162 ambientColour, class_1162 diffuseColour, class_1162 specularColour, float reflectance) {
        this.ambientColour = ambientColour;
        this.diffuseColour = diffuseColour;
        this.specularColour = specularColour;
        this.reflectance = reflectance;
    }
}
