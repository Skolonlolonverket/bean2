package com.pyr0r4t.photona.registry;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;

public class BombItem extends class_1792 {
    public BombItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 user, class_1268 hand) {
        class_1799 itemStack = user.method_5998(hand); // creates a new ItemStack instance of the user's itemStack in-hand
        level.method_43128(null, user.method_23317(), user.method_23318(), user.method_23321(), class_3417.field_15058, class_3419.field_15254, 0.5F, 1F); // plays a globalSoundEvent
		/*
		user.getItemCooldownManager().set(this, 5);
		Optionally, you can add a cooldown to your item's right-click use, similar to Ender Pearls.
		*/
        if (!level.field_9236) {
            BombEntity bombEntity = new BombEntity(level, user);
            bombEntity.method_16940(itemStack);
            bombEntity.method_24919(user, user.method_36455(), user.method_36454(), 0.0F, 1.5F, 0F);
                        /*
                        snowballEntity.setProperties(user, user.getPitch(), user.getYaw(), 0.0F, 1.5F, 1.0F);
                        In 1.17,we will use setProperties instead of setVelocity.
                        */
            level.method_8649(bombEntity); // spawns entity
        }

        user.method_7259(class_3468.field_15372.method_14956(this));
        if (!user.method_31549().field_7477) {
            itemStack.method_7934(1); // decrements itemStack if user is not in creative mode
        }

        return class_1271.method_22427(itemStack);
    }
}
