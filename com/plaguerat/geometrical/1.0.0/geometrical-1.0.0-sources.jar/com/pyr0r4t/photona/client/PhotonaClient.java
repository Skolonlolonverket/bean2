package com.pyr0r4t.photona.client;

import com.pyr0r4t.photona.client.registry.BigFlash;
import com.pyr0r4t.photona.client.render.lalastupidrender;
import com.pyr0r4t.photona.registry.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_717;
import net.minecraft.class_953;
import java.io.IOException;

import static com.pyr0r4t.photona.registry.IHoldTrash.ope;
import static com.pyr0r4t.photona.registry.IHoldTrash.opecount;
import static java.lang.Math.cos;
import static java.lang.Math.sin;

public class PhotonaClient implements ClientModInitializer {

	private static final class_2960 TEXTURE_PATH = new class_2960("photona", "textures/misc/debug.png");
	private static final class_2960 TEXTURE_PATH2 = new class_2960("photona", "textures/misc/debug2.png");
	private static final class_2960 TEXTURE_PATH3 = new class_2960("photona", "textures/misc/dirtius.png");
	private static final class_2960 TEXTURE_PATH4 = new class_2960("photona", "textures/misc/kerbin.png");
	private static final class_2960 TEXTURE_PATH5 = new class_2960("photona", "textures/misc/mun.png");
	private static final class_2960 TEXTURE_PATH6 = new class_2960("photona", "textures/block/glow.png");
	private static final class_2960 DUMMY_WHITE = new class_2960("minecraft", "textures/misc/white.png");

	@Override
	public void onInitializeClient() {
		//LightManager.INSTANCE.registerBlockLight(Blocks.SOUL_LANTERN, state -> new ColorPointLight.Template(8, 0xff74F1F5));
		net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry.getInstance().register(
				ModParticles.BOMB_FLASH,
				BigFlash.Provider::new
		);

		/*CoreShaderRegistrationCallback.EVENT.register(context -> {
			try {
				// Ensure your_mod_id matches the name of your assets folder exactly
				context.register(
						new ResourceLocation("photona", "rendertype_glow_sphere"),
						DefaultVertexFormat.POSITION_TEX, // Format must match your .json attributes
						shaderInstance -> {
							// Store the compiled shader in your rendering class tracking hook
							lalastupidrender.GLOW_SPHERE_SHADER = shaderInstance;
						}
				);
			} catch (IOException e) {
				// Log or handle loading failures gracefully
				System.err.println("Failed to compile custom glow sphere shader!");
				e.printStackTrace();
			}
		});*/

		// 2. Tell the client how to render the smoke (using vanilla Smoke template)
		ParticleFactoryRegistry.getInstance().register(
				ModParticles.BOMB_SMOKE,
				class_717.class_718::new
		);
		ModItems.initializeClient();
		BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.SPCDOOR, class_1921.method_23581());
		EntityRendererRegistry.register(ModProjectiles.BombEntityType, (context) ->
				new class_953(context));
		WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
			class_310 mc = class_310.method_1551();
			if (mc.field_1687 == null || mc.field_1724 == null) return;

			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			// Step B: Absolute location settings
			double targetX = 8.0;
			double targetY = -59.0;
			double targetZ = 8.0;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.drawCube(poseStack, targetX, targetY, targetZ, 1.0f, 1.0f, 1.0f, 0.0f, 0.5f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
			class_310 mc = class_310.method_1551();
			if (mc.field_1687 == null || mc.field_1724 == null) return;

			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			// Step B: Absolute location settings
			double targetX = 10.0;
			double targetY = -59.0;
			double targetZ = 8.0;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.drawLowPyramid(poseStack, targetX, targetY, targetZ, 1.0f, 1.0f, 1.0f, 0.0f, 0.5f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
			class_310 mc = class_310.method_1551();
			if (mc.field_1687 == null || mc.field_1724 == null) return;

			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			// Step B: Absolute location settings
			double targetX = 12.0;
			double targetY = -59.0;
			double targetZ = 8.0;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.drawHighPyramid(poseStack, targetX, targetY, targetZ, 1.0f, 1.0f, 1.0f, 0.0f, 0.5f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			// Step B: Absolute location settings
			double targetX = 14.0;
			double targetY = -59.0;
			double targetZ = 8.0;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.drawSphere(poseStack, TEXTURE_PATH3, targetX, targetY, targetZ, 1.0f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_ENTITIES.register(context -> {
			class_310 mc = class_310.method_1551();
			if (mc.field_1687 == null || mc.field_1724 == null) return;

			// matrix + camera
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			// location
			double targetX = 16.0;
			double targetY = -59.0;
			double targetZ = 8.0;

			// no move
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// render
			lalastupidrender.drawCubeWithTexture(poseStack, TEXTURE_PATH, targetX, targetY, targetZ, 1.0f);

			// fix the mAtRiX
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_ENTITIES.register(context -> {
			class_310 mc = class_310.method_1551();
			if (mc.field_1687 == null || mc.field_1724 == null) return;

			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			// Step B: Absolute location settings
			double targetX = 18.0;
			double targetY = -59.0;
			double targetZ = 8.0;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.drawCubeWithTexture(poseStack, TEXTURE_PATH2, targetX, targetY, targetZ, 1.0f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_ENTITIES.register(context -> {

			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			// Step B: Absolute location settings
			double targetX = 20.0;
			double targetY = -59.0;
			double targetZ = 8.0;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.drawFresnelSphere(poseStack, DUMMY_WHITE, targetX, targetY, targetZ, 1.0f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.LAST.register(context -> {
			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			// Step B: Absolute location settings
			double targetX = 22.0;
			double targetY = -59.0;
			double targetZ = 8.0;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.sphereiguess(poseStack, TEXTURE_PATH3, targetX, targetY, targetZ, 1.0f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			float time = (float) (class_310.method_1551().field_1687.method_8510() + class_310.method_1551().method_1488());
			float spinOffset = (time * 0.005f) % 1.0f;

			// Step B: Absolute location settings
			double targetX = 24.0;
			double targetY = -59.0;
			double targetZ = 8.0;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.drawSpinSphere(poseStack, TEXTURE_PATH4, spinOffset, targetX, targetY, targetZ, 1.0f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
			// 1. Check if there are any coordinates to draw first
			if (IHoldTrash.ope.isEmpty()) {
				return;
			}

			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			float time = (float) (class_310.method_1551().field_1687.method_8510() + class_310.method_1551().method_1488());
			float spinOffset = (time * 0.005f) % 1.0f;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// 2. SAFE LOOP: Step by 3 because X, Y, and Z take up 3 slots total
			for (int i = 0; i < IHoldTrash.ope.size(); i += 3) {

				// Safety check to ensure we don't accidentally read past the end of the array
				if (i + 2 >= IHoldTrash.ope.size()) {
					break;
				}

				// Step B: Absolute location settings
				float lalx = IHoldTrash.getItemX(i);
				float laly = IHoldTrash.getItemY(i);
				float lalz = IHoldTrash.getItemZ(i);

				// Step D: Draw a semi-transparent blue square in the world
				lalastupidrender.drawSpinSphere(poseStack, TEXTURE_PATH4, spinOffset, lalx, laly, lalz, 1.0f);
			}

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			float time = (float) (class_310.method_1551().field_1687.method_8510() + class_310.method_1551().method_1488());
			float spinOffset = (time * 0.005f); //% 1.0f;
			float angle = (time * 0.05f); //% 6.25f;
			float distanceOut = 3.0f;

			// Step B: Absolute location settings
			double centerX = 8.0f;
			double targetY = -55.0f;
			double centerZ = 8.0f;

			double tipX = centerX + cos(angle) * distanceOut;
			double tipZ = centerZ + sin(angle) * distanceOut;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.drawSpinSphere(poseStack, TEXTURE_PATH4, spinOffset, tipX, targetY, tipZ, 1.0f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			float time = (float) (class_310.method_1551().field_1687.method_8510() + class_310.method_1551().method_1488());
			float spinOffset = (time * 0.005f); //% 1.0f;
			float angle = (time * 0.05f); // % 6.25f;
			float angleAngle = (time * 0.05f); //% 6.25f;
			float distanceDistanceOut = 3.0f;
			float distanceOut = 1.0f;

			// Step B: Absolute location settings

			double centerCenterX = 8.0f;
			double targetY = -55.0f;
			double centerCenterZ = 8.0f;

			double centerX = centerCenterX + cos(angleAngle) * distanceDistanceOut;
			double centerZ = centerCenterZ + sin(angleAngle) * distanceDistanceOut;

			double tipX = centerX + cos(angle) * distanceOut;
			double tipZ = centerZ + sin(angle) * distanceOut;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.drawSpinSphere(poseStack, TEXTURE_PATH5, spinOffset, tipX, targetY, tipZ, 0.5f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			// Step B: Absolute location settings
			double targetX = 8.0;
			double targetY = -55.0;
			double targetZ = 8.0;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.drawSphere(poseStack, TEXTURE_PATH6, targetX, targetY, targetZ, 3.0f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			// Step B: Absolute location settings
			double targetX = 1.0;
			double targetY = 1.0;
			double targetZ = 1.0;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			//poseStack.translate(targetX - cameraPos.x, targetY - cameraPos.y, targetZ - cameraPos.z);
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.drawBloomSphere(poseStack, TEXTURE_PATH6, targetX, targetY, targetZ, 20.0f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			//float time = (float) (Minecraft.getInstance().level.getGameTime() + Minecraft.getInstance().getFrameTime());
			float time = class_310.method_1551().field_1687.method_8510() + context.tickDelta();
			float spinOffset = (time * 0.005f); //% 1.0f;
			float angle = (time * 0.05f); //% 6.25f;
			float distanceOut = 65.0f;

			// Step B: Absolute location settings
			double centerX = 1.0f;
			double targetY = 1.0f;
			double centerZ = 1.0f;

			double tipX = centerX + cos(angle) * distanceOut;
			double tipZ = centerZ + sin(angle) * distanceOut;

            //tipX = 70.0d;
            //tipZ = 70.0d;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.drawSpinSphere(poseStack, TEXTURE_PATH4, spinOffset, tipX, targetY, tipZ, 10.0f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
		WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
			// Step A: Extract camera positioning and current matrix
			class_243 cameraPos = context.camera().method_19326();
			class_4587 poseStack = context.matrixStack();

			//float time = (float) (Minecraft.getInstance().level.getGameTime() + Minecraft.getInstance().getFrameTime());
			float time = class_310.method_1551().field_1687.method_8510() + context.tickDelta();
			float spinOffset = (time * 0.005f);//% 1.0f;
			float angle = (time * 0.05f); // % 6.25f;
			float angleAngle = (time * 0.05f); //% 6.25f;
			float distanceDistanceOut = 65.0f;
			float distanceOut = 40.0f;

			// Step B: Absolute location settings

			double centerCenterX = 1.0f;
			double targetY = 1.0f;
			double centerCenterZ = 1.0f;

			double centerX = centerCenterX + cos(angleAngle) * distanceDistanceOut;
			double centerZ = centerCenterZ + sin(angleAngle) * distanceDistanceOut;

			double tipX = centerX + cos(angle) * distanceOut;
			double tipZ = centerZ + sin(angle) * distanceOut;

            //tipX = 40.0d;
            //tipZ = 40.0d;

			// Step C: Offset drawing using the player's movement coordinates
			poseStack.method_22903();
			poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

			// Step D: Draw a semi-transparent blue square in the world
			lalastupidrender.drawSpinSphere(poseStack, TEXTURE_PATH5, spinOffset, tipX, targetY, tipZ, 5.0f);

			// Step E: Restore the matrix
			poseStack.method_22909();
		});
	}
}