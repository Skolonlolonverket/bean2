package com.pyr0r4t.photona;

import com.pyr0r4t.photona.registry.ModBlocks;
import com.pyr0r4t.photona.registry.ModItems;
import com.pyr0r4t.photona.registry.ModParticles;
import com.pyr0r4t.photona.registry.ModProjectiles;
import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import org.intellij.lang.annotations.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Photona implements ModInitializer {
	public static final String MOD_ID = "photona";

	// This logger is used to write text to the console and the log file.
	// It is considered best practice to use your mod id as the logger's name.
	// That way, it's clear which mod wrote info, warnings, and errors.
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static final class_1761 TEST_STUFF = FabricItemGroupBuilder.build(new class_2960(MOD_ID, "test_stuff"),
			() -> new class_1799(ModItems.BOOK_OF_SORCERY));

	@Override
	public void onInitialize() {
		ModItems.initialize();
		ModBlocks.initialize();
		ModProjectiles.initialize();
		ModParticles.initialize();

		LOGGER.info("Initializing the bugs!");
		LOGGER.info("If you crash one more time Im going to crash out and crash EVERYTHING THAT HAS EVER EXISTED AND EVERYTHING THAT WILL EXIST");
	}

	public static class_2960 id(String path) {
		return new class_2960(MOD_ID, path);
	}
}
