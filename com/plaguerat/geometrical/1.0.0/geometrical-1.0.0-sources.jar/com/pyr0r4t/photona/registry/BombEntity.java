package com.pyr0r4t.photona.registry;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2392;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3857;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import java.util.List;

import static com.pyr0r4t.photona.registry.ModItems.BOMB_ITEM;
import static com.pyr0r4t.photona.registry.ModProjectiles.BombEntityType;

public class BombEntity extends class_3857 {
    public BombEntity(class_1299<? extends class_3857> entityType, class_1937 level) {
        super(entityType, level);
    }

    public BombEntity(class_1937 level, class_1309 owner) {
        super(BombEntityType, owner, level); // null will be changed later
    }

    public BombEntity(class_1937 level, double x, double y, double z) {
        super(BombEntityType, x, y, z, level); // null will be changed later
    }
    @Override
    protected class_1792 method_16942() {
        return BOMB_ITEM; // We will configure this later, once we have created the ProjectileItem.
    }

    @Environment(EnvType.CLIENT)
    private class_2394 getParticleParameters() { // Not entirely sure, but probably has do to with the snowball's particles. (OPTIONAL)
        class_1799 itemStack = this.method_7495();
        return (class_2394)(itemStack.method_7960() ? class_2398.field_11215 : new class_2392(class_2398.field_11218, itemStack));
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void method_5711(byte status) { // Also not entirely sure, but probably also has to do with the particles. This method (as well as the previous one) are optional, so if you don't understand, don't include this one.
        if (status == 3) {
            for (int i = 0; i < 150; ++i) {
                // Calculate a random circular or spherical velocity spreading outwards
                double xSpeed = (this.field_5974.method_43058() - 0.5D) * 0.5D;
                double ySpeed = (this.field_5974.method_43058() - 0.5D) * 0.5D;
                double zSpeed = (this.field_5974.method_43058() - 0.5D) * 0.5D;

                this.field_6002.method_8494(
                        ModParticles.BOMB_SMOKE, // Your custom particle type
                        this.method_23317(), this.method_23318(), this.method_23321(), // Origin coordinates
                        xSpeed, ySpeed, zSpeed                  // Speeds/Vectors
                );
            }
            this.field_6002.method_8494(
                    ModParticles.BOMB_FLASH, // Your custom particle type
                    this.method_23317(), this.method_23318(), this.method_23321(), // Origin coordinates
                    0, 0, 0                  // Speeds/Vectors
            );
        }
        else {
            super.method_5711(status);
        }

    }

    @Override
    protected void method_7454(class_3966 entityHitResult) { // called on entity hit.
        super.method_7454(entityHitResult);
        class_1297 entity = entityHitResult.method_17782(); // sets a new Entity instance as the EntityHitResult (victim)
        int i = entity instanceof class_1657 ? 3 : 0; // sets i to 3 if the Entity instance is an instance of BlazeEntity
        entity.method_5643(class_1282.method_5524(this, this.method_24921()), (float)i); // deals damage

        if (entity instanceof class_1309 livingEntity) { // checks if entity is an instance of LivingEntity (meaning it is not a boat or minecart)
            livingEntity.method_6092((new class_1293(class_1294.field_5919, 20 * 3, 0))); // applies a status effect
            livingEntity.method_6092((new class_1293(class_1294.field_5909, 20 * 3, 2))); // applies a status effect
            livingEntity.method_6092((new class_1293(class_1294.field_5899, 20 * 3, 1))); // applies a status effect
            livingEntity.method_5783(class_3417.field_14833, 2F, 1F); // plays a sound for the entity hit only
        }
    }

    @Override
    protected void method_24920(class_3965 result) { // called on collision with a block
        super.method_24920(result);
        double x = this.method_23317();
        double y = this.method_23318();
        double z = this.method_23321();
        float explosionPower = 3.0F;

        // 1. SILENTLY BREAK BLOCKS REGARDING BLAST RESISTANCE
        int blockRadius = (int) Math.ceil(explosionPower);
        class_2338 centerPos = new class_2338(x, y, z);
        if (!this.field_6002.field_9236) {

            for (int dx = -blockRadius; dx <= blockRadius; dx++) {
                for (int dy = -blockRadius; dy <= blockRadius; dy++) {
                    for (int dz = -blockRadius; dz <= blockRadius; dz++) {
                        double distanceSq = dx * dx + dy * dy + dz * dz;
                        if (distanceSq <= explosionPower * explosionPower) {
                            class_2338 targetPos = centerPos.method_10069(dx, dy, dz);
                            class_2680 state = this.field_6002.method_8320(targetPos);

                            if (!state.method_26215()) {
                                float blastResistance = state.method_26204().method_9520();
                                double distance = Math.sqrt(distanceSq);
                                float powerAtBlock = explosionPower - ((float) distance * 0.3F);

                                if (powerAtBlock > (blastResistance / 5.0F) && state.method_26214(this.field_6002, targetPos) >= 0) {
                                    class_2248.method_9497(state, this.field_6002, targetPos);
                                    this.field_6002.method_8652(targetPos, class_2246.field_10124.method_9564(), 3);
                                }
                            }
                        }
                    }
                }
            }

            // 2. DAMAGE & KNOCKBACK WITH WALL PROTECTION (RAYCASTING)
            class_238 explosionBox = new class_238(x - explosionPower, y - explosionPower, z - explosionPower, x + explosionPower, y + explosionPower, z + explosionPower);
            List<class_1309> entities = this.field_6002.method_18467(class_1309.class, explosionBox);
            class_243 explosionCenter = new class_243(x, y, z);

            for (class_1309 entity : entities) {
                double distanceSq = entity.method_5649(x, y, z);
                float exposure = class_1927.method_17752(explosionCenter, entity);

                // Fixed Equation: Checks if entity is within the blast radius sphere
                if (distanceSq <= (double)(explosionPower * explosionPower)) {
                    double distance = Math.sqrt(distanceSq);
                    double proportionalDamage = 1.0D - (distance / (double) explosionPower);

                    float finalDamage = (float) (proportionalDamage * 12.0D * (double) exposure);
                    entity.method_5643(class_1282.method_5536(this, this.method_24921()), finalDamage);

                    class_243 launchDirection = new class_243(entity.method_23317() - x, entity.method_23318() - y, entity.method_23321() - z).method_1029();
                    double knockbackStrength = proportionalDamage * 1.5D * (double) exposure;
                    entity.method_18799(entity.method_18798().method_1019(launchDirection.method_1021(knockbackStrength)));
                }
            }
        }

        // 3. PLAY AUDIO MANUALLY
        this.field_6002.method_8396(
                null, centerPos,
                net.minecraft.class_3417.field_15152,
                net.minecraft.class_3419.field_15245,
                4.0F,
                (1.0F + (this.field_6002.field_9229.method_43057() - this.field_6002.field_9229.method_43057()) * 0.2F) * 0.7F
        );

        // 4. TRIGGER ONLY CUSTOM PARTICLES
        this.field_6002.method_8421(this, (byte) 3);

        this.method_31472();

    }
}
