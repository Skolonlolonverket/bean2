package com.pyr0r4t.photona.registry;

import com.pyr0r4t.photona.Photona;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3614;
import net.minecraft.class_4970;

public class ModBlocks {
    public static class_2248 register(class_2248 block, String name, boolean shouldRegisterItem) {
        // Register the block and its item.
        class_2960 id = new class_2960(Photona.MOD_ID, name);

        // Sometimes, you may not want to register an item for the block.
        // Eg: if it's a technical block like `minecraft:air` or `minecraft:end_gateway`
        if (shouldRegisterItem) {
            class_1747 blockItem = new class_1747(block, new class_1792.class_1793().method_7892(Photona.TEST_STUFF));
            class_2378.method_10230(class_2378.field_11142, id, blockItem);
        }

        return class_2378.method_10230(class_2378.field_11146, id, block);
    }
    public static final class_2248 SPCDOOR = register(
            new EPicDoor(class_4970.class_2251.method_9637(class_3614.field_15953).method_9632(3600000.0f).method_9626(class_2498.field_11533)),
            "spcdoor",
            true
    );
    public static final class_2248 SPCTRAPDOOR = register(
            new EpicTrapdoor(class_4970.class_2251.method_9637(class_3614.field_15953).method_9632(3600000.0f).method_9626(class_2498.field_11533)),
            "spctrapdoor",
            true
    );
    public static final class_2248 SPCFLOOR = register(
            new class_2248(class_4970.class_2251.method_9637(class_3614.field_15953).method_9632(3600000.0f).method_9626(class_2498.field_23265)),
            "spcfloor",
            true
    );
    public static final class_2248 SPCWALL = register(
            new class_2248(class_4970.class_2251.method_9637(class_3614.field_15953).method_9632(3600000.0f).method_9626(class_2498.field_23265)),
            "spcwall",
            true
    );
    public static final class_2248 BACON = register(
            new class_2248(class_4970.class_2251.method_9637(class_3614.field_15949).method_9632(3600000.0f).method_9626(class_2498.field_23265)),
            "bacon",
            true
    );
    public static void initialize() {}
}
