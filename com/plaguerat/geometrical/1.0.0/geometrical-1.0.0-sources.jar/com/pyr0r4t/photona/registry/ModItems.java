package com.pyr0r4t.photona.registry;

import com.lowdragmc.shimmer.client.light.ColorPointLight;
import com.lowdragmc.shimmer.client.light.LightManager;
import com.pyr0r4t.photona.Photona;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

public class ModItems {
    public static class_1792 register(class_1792 item, String id) {
        // Create the identifier for the item.
        class_2960 itemID = new class_2960(Photona.MOD_ID, id);

        // Register the item.
        class_1792 registeredItem = class_2378.method_10230(class_2378.field_11142, itemID, item);

        // Return the registered item!
        return registeredItem;
    }
    public static final class_1792 BOOK_OF_SORCERY = register(
            // Ignore the food component for now, we'll cover it later in the food section.
            new BookOfSorcery(new FabricItemSettings().method_7892(Photona.TEST_STUFF)),
            "book_of_sorcery"
    );
    public static final class_1792 BOMB_ITEM = register(
            // Ignore the food component for now, we'll cover it later in the food section.
            new BombItem(new FabricItemSettings().method_7892(Photona.TEST_STUFF)),
            "bomb_item"
    );
    public static void initialize() {
    }

    public static void initializeClient() {
        // Register the dynamic Shimmer light directly to your book item here!
        class_1792 finalItem = class_2378.field_11142.method_10223(new class_2960(Photona.MOD_ID, "book_of_sorcery"));

        if (finalItem != null) {
            LightManager.INSTANCE.registerItemLight(finalItem, (itemStack ->
                    new ColorPointLight.Template(10f, 0xFF5500)
            ));
        }
    }
}