package com.pyr0r4t.photona.registry;

import net.minecraft.class_2533;

public class EpicTrapdoor extends class_2533 {
    public EpicTrapdoor(class_2251 props) {
        super(props);
    }
}
