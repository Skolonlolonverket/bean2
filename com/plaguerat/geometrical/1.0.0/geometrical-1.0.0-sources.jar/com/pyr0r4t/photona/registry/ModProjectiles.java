package com.pyr0r4t.photona.registry;

import com.pyr0r4t.photona.Photona;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4048;

public class ModProjectiles {
    public static final class_1299<BombEntity> BombEntityType = class_2378.method_10230(
            class_2378.field_11145,
            new class_2960(Photona.MOD_ID, "bombentity"),
            FabricEntityTypeBuilder.<BombEntity>create(class_1311.field_17715, BombEntity::new)
                    .dimensions(class_4048.method_18385(0.25F, 0.25F)) // dimensions in Minecraft units of the projectile
                    .trackRangeBlocks(4).trackedUpdateRate(10) // necessary for all thrown projectiles (as it prevents it from breaking, lol)
                    .build() // VERY IMPORTANT DONT DELETE FOR THE LOVE OF GOD PSLSSSSSS
    );
    public static void initialize() {}
}
