package com.pyr0r4t.photona.registry;

import static com.pyr0r4t.photona.registry.IHoldTrash.ope;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class BookOfSorcery extends class_1792 {
    public BookOfSorcery(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 user, class_1268 hand) {
        class_1799 itemStack = user.method_5998(hand);
        IHoldTrash warehouse = new IHoldTrash();
        int x = (int) user.method_23317();
        int y = (int) user.method_23318();
        int z = (int) user.method_23321();
        warehouse.addItem(x);
        warehouse.addItem(y+1);
        warehouse.addItem(z);
        return class_1271.method_22427(itemStack);
    }
}
