package com.pyr0r4t.photona.client.registry; // <-- Fixed package path to match your folder!

import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

public class BigFlash extends class_4003 {

    protected BigFlash(class_638 clientLevel, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, class_4002 sprites) {
        super(clientLevel, x, y, z, xSpeed, ySpeed, zSpeed);

        // In Mojmaps, physics variables use full names instead of letters like xd/yd/zd!
        this.field_28786 = 0.96F;
        this.field_3858 = x;
        this.field_3838 = y;
        this.field_3856 = z;
        this.field_3852 = xSpeed;
        this.field_3869 = ySpeed;
        this.field_3850 = zSpeed;

        this.field_3847 = 20;
        this.method_18142(sprites);

        // --- SIZE INJECTION MULTIPLIER ---
        this.field_17867 *= 10.0F; // Makes the particle huge!
    }

    @Override
    public class_3999 method_18122() {
        return class_3999.field_17828;
    }

    @Override
    public void method_3070() {
        // Safe reference to the parent tick logic
        super.method_3070();
        // Gently drift upward like real explosive heat
        this.field_3869 += 0.0D;
    }

    // THE FACTORY PROVIDER LINK
    public static class Provider implements class_707<class_2400> {
        private final class_4002 sprites;

        public Provider(class_4002 sprites) {
            this.sprites = sprites;
        }

        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            BigFlash particle = new BigFlash(level, x, y, z, xSpeed, ySpeed, zSpeed, this.sprites);
            particle.method_18140(this.sprites);
            return particle;
        }
    }
}