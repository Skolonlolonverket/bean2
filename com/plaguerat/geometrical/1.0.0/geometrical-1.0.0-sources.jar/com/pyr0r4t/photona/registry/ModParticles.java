package com.pyr0r4t.photona.registry;

import com.pyr0r4t.photona.Photona;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;

public class ModParticles {
    public static final class_2400 BOMB_SMOKE = class_2378.method_10230(
            class_2378.field_11141,
            new class_2960(Photona.MOD_ID, "bomb_smoke"),
            FabricParticleTypes.simple() // false means it doesn't require extra data like colors
    );
    public static final class_2400 BOMB_FLASH = class_2378.method_10230(
            class_2378.field_11141,
            new class_2960(Photona.MOD_ID, "bomb_flash"),
            FabricParticleTypes.simple() // false means it doesn't require extra data like colors
    );
    public static final class_2400 GLOW = class_2378.method_10230(
            class_2378.field_11141,
            new class_2960(Photona.MOD_ID, "glow"),
            FabricParticleTypes.simple() // false means it doesn't require extra data like colors
    );
    public static void initialize() {}
}
