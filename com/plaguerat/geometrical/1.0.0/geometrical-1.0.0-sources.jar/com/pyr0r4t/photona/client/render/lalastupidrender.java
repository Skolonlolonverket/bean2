package com.pyr0r4t.photona.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.class_1159;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5944;
import net.minecraft.class_757;

public class lalastupidrender {

    /**
     * Draws a flat colored quad floating horizontally in the 3D world.
     */
    public static void drawCube(class_4587 poseStack, double x, double y, double z, float size, float r, float g, float b, float a) {
        class_289 tessellator = class_289.method_1348();
        class_287 bufferBuilder = tessellator.method_1349();

        // 1. Get the current position transformation matrix from the game engine
        class_1159 matrix = poseStack.method_23760().method_23761();

        // 2. Configure RenderSystem states for 3D blending and depth
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest(); // Ensures blocks hide your render if they are in front
        RenderSystem.setShader(class_757::method_34540);

        // 3. Begin building using the POSITION_COLOR vertex format
        bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

        // 4. Feed vertices. Apply the position matrix multiplication using '.matrix()'
        // This example draws a flat square right above the specified X, Y, Z coordinate
        //bottom
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        //top
        bufferBuilder.method_22918(matrix, (float)x, (float)y + size, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y + size, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y + size, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y + size, (float)z).method_22915(r, g, b, a).method_1344();
        //left
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y + size, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y + size, (float)z).method_22915(r, g, b, a).method_1344();
        //right
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y + size, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y + size, (float)z + size).method_22915(r, g, b, a).method_1344();
        //front
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y + size, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y + size, (float)z).method_22915(r, g, b, a).method_1344();
        //back
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y + size, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y + size, (float)z).method_22915(r, g, b, a).method_1344();

        // 5. Draw and upload vertices
        tessellator.method_1350();

        // 6. Reset graphics state
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    public static void drawLowPyramid(class_4587 poseStack, double x, double y, double z, float size, float r, float g, float b, float a) {
        class_289 tessellator = class_289.method_1348();
        class_287 bufferBuilder = tessellator.method_1349();

        // 1. Get the current position transformation matrix from the game engine
        class_1159 matrix = poseStack.method_23760().method_23761();

        // 2. Configure RenderSystem states for 3D blending and depth
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest(); // Ensures blocks hide your render if they are in front
        RenderSystem.setShader(class_757::method_34540);

        // 3. Begin building using the POSITION_COLOR vertex format
        bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

        // 4. Feed vertices. Apply the position matrix multiplication using '.matrix()'
        // This example draws a flat square right above the specified X, Y, Z coordinate
        //bottom
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z).method_22915(r, g, b, a).method_1344();

        // 5. Draw and upload vertices
        tessellator.method_1350();

        bufferBuilder.method_1328(class_293.class_5596.field_27379, class_290.field_1576);

        //front
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size / 2, (float)y + size / 3 * 2, (float)z + size / 2).method_22915(r, g, b, a).method_1344();
        //back
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size / 2, (float)y + size / 3 * 2, (float)z + size / 2).method_22915(r, g, b, a).method_1344();
        //left
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size / 2, (float)y + size / 3 * 2, (float)z + size / 2).method_22915(r, g, b, a).method_1344();
        //right
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size / 2, (float)y + size / 3 * 2, (float)z + size / 2).method_22915(r, g, b, a).method_1344();

        tessellator.method_1350();

        // 6. Reset graphics state
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    public static void drawHighPyramid(class_4587 poseStack, double x, double y, double z, float size, float r, float g, float b, float a) {
        class_289 tessellator = class_289.method_1348();
        class_287 bufferBuilder = tessellator.method_1349();

        // 1. Get the current position transformation matrix from the game engine
        class_1159 matrix = poseStack.method_23760().method_23761();

        // 2. Configure RenderSystem states for 3D blending and depth
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest(); // Ensures blocks hide your render if they are in front
        RenderSystem.setShader(class_757::method_34540);

        // 3. Begin building using the POSITION_COLOR vertex format
        bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

        // 4. Feed vertices. Apply the position matrix multiplication using '.matrix()'
        // This example draws a flat square right above the specified X, Y, Z coordinate
        //bottom
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z).method_22915(r, g, b, a).method_1344();

        // 5. Draw and upload vertices
        tessellator.method_1350();

        bufferBuilder.method_1328(class_293.class_5596.field_27379, class_290.field_1576);

        //front
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size / 2, (float)y + size, (float)z + size / 2).method_22915(r, g, b, a).method_1344();
        //back
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size / 2, (float)y + size, (float)z + size / 2).method_22915(r, g, b, a).method_1344();
        //left
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size / 2, (float)y + size, (float)z + size / 2).method_22915(r, g, b, a).method_1344();
        //right
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z + size).method_22915(r, g, b, a).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size / 2, (float)y + size, (float)z + size / 2).method_22915(r, g, b, a).method_1344();

        tessellator.method_1350();

        // 6. Reset graphics state
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
    public static void drawSphere(class_4587 poseStack, class_2960 texture, double x, double y, double z, float radius) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        class_289 tessellator = class_289.method_1348();
        class_287 bufferBuilder = tessellator.method_1349();
        class_1159 matrix = poseStack.method_23760().method_23761();

        // 2. Configure RenderSystem states for 3D blending and depth
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderTexture(0, texture);

        bufferBuilder.method_1328(class_293.class_5596.field_27380, class_290.field_1585);

        int slices = 24;
        int stacks = 24;

        float cx = (float) x + 0.5f;
        float cy = (float) y + 0.5f;
        float cz = (float) z + 0.5f;
        radius = radius / 2;

        for (int i = 0; i < stacks; i++) {
            float lat0 = (float) Math.PI * (-0.5f + (float) i / stacks);
            float y0  = (float) Math.sin(lat0);
            float r0  = (float) Math.cos(lat0);

            float lat1 = (float) Math.PI * (-0.5f + (float) (i + 1) / stacks);
            float y1  = (float) Math.sin(lat1);
            float r1  = (float) Math.cos(lat1);

            for (int j = 0; j <= slices; j++) {
                float lng = (float) (2.0 * Math.PI * (float) j / slices);
                float xCos = (float) Math.cos(lng);
                float zSin = (float) Math.sin(lng);

                float u = (float) j / slices;
                float v0 = (float) i / stacks;
                float v1 = (float) (i + 1) / stacks;

                // Vertex A (Bottom ring) - Swapped Y and Z parameters
                bufferBuilder.method_22918(matrix, cx + radius * xCos * r0, cy + radius * y0, cz + radius * zSin * r0)
                        .method_22913(u, v0).method_1344();

                // Vertex B (Top ring) - Swapped Y and Z parameters
                bufferBuilder.method_22918(matrix, cx + radius * xCos * r1, cy + radius * y1, cz + radius * zSin * r1)
                        .method_22913(u, v1).method_1344();
            }
        }

        // 5. Draw and upload vertices
        tessellator.method_1350();

        // 6. Reset graphics state
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    public static void drawCubeWithTexture(class_4587 poseStack, class_2960 texture, double x, double y, double z, float size) {
        class_289 tessellator = class_289.method_1348();
        class_287 bufferBuilder = tessellator.method_1349();

        // 1. Get the current position transformation matrix from the game engine
        class_1159 matrix = poseStack.method_23760().method_23761();

        // 2. Configure RenderSystem states for 3D blending and depth
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest(); // Ensures blocks hide your render if they are in front
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderTexture(0, texture);

        // 3. Begin building using the POSITION_COLOR vertex format
        bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1585);

        // 4. Feed vertices. Apply the position matrix multiplication using '.matrix()'
        // This example draws a flat square right above the specified X, Y, Z coordinate
        //bottom
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z).method_22913(0.0f, 0.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z + size).method_22913(0.0f, 1.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z + size).method_22913(1.0f, 1.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z).method_22913(1.0f, 0.0f).method_1344();
        //top
        bufferBuilder.method_22918(matrix, (float)x, (float)y + size, (float)z).method_22913(0.0f, 0.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y + size, (float)z + size).method_22913(0.0f, 1.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y + size, (float)z + size).method_22913(1.0f, 1.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y + size, (float)z).method_22913(1.0f, 0.0f).method_1344();
        //left
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z).method_22913(0.0f, 0.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z).method_22913(0.0f, 1.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y + size, (float)z).method_22913(1.0f, 1.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y + size, (float)z).method_22913(1.0f, 0.0f).method_1344();
        //right
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z + size).method_22913(0.0f, 0.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z + size).method_22913(0.0f, 1.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y + size, (float)z + size).method_22913(1.0f, 1.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y + size, (float)z + size).method_22913(1.0f, 0.0f).method_1344();
        //front
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z).method_22913(0.0f, 0.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y, (float)z + size).method_22913(0.0f, 1.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y + size, (float)z + size).method_22913(1.0f, 1.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x, (float)y + size, (float)z).method_22913(1.0f, 0.0f).method_1344();
        //back
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z).method_22913(0.0f, 0.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y, (float)z + size).method_22913(0.0f, 1.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y + size, (float)z + size).method_22913(1.0f, 1.0f).method_1344();
        bufferBuilder.method_22918(matrix, (float)x + size, (float)y + size, (float)z).method_22913(1.0f, 0.0f).method_1344();

        // 5. Draw and upload vertices
        tessellator.method_1350();

        // 6. Reset graphics state
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
    public static void drawFresnelSphere(class_4587 poseStack, class_2960 texture, double x, double y, double z, float radius) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        class_5944 myCustomShader = com.pyr0r4t.photona.client.render.PhotonaShaders.getSphereShader();

        if (myCustomShader == null) return;

        class_289 tesselator = class_289.method_1348();
        class_287 bufferBuilder = tesselator.method_1349();
        class_1159 matrix = poseStack.method_23760().method_23761();

        // 2. Configure RenderSystem states for 3D blending and depth
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(() -> myCustomShader);
        RenderSystem.setShaderTexture(0, texture);

        RenderSystem.setupShaderLights(myCustomShader);

        // Uploads matrix information, Projection values, and GameTime straight into your .vsh / .fsh files
        myCustomShader.method_34586();

        bufferBuilder.method_1328(class_293.class_5596.field_27380, class_290.field_20887);

        int slices = 24;
        int stacks = 24;

        float cx = (float) x + 0.5f;
        float cy = (float) y + 0.5f;
        float cz = (float) z + 0.5f;
        radius = radius / 2;

        for (int i = 0; i < stacks; i++) {
            float lat0 = (float) Math.PI * (-0.5f + (float) i / stacks);
            float y0  = (float) Math.sin(lat0);
            float r0  = (float) Math.cos(lat0);

            float lat1 = (float) Math.PI * (-0.5f + (float) (i + 1) / stacks);
            float y1  = (float) Math.sin(lat1);
            float r1  = (float) Math.cos(lat1);

            for (int j = 0; j <= slices; j++) {
                float lng = (float) (2.0 * Math.PI * (float) j / slices);
                float xCos = (float) Math.cos(lng);
                float zSin = (float) Math.sin(lng);

                float u = (float) j / slices;
                float v0 = (float) i / stacks;
                float v1 = (float) (i + 1) / stacks;

                // Vertex A (Bottom ring) - Swapped Y and Z parameters
                bufferBuilder.method_22918(matrix, cx + radius * xCos * r0, cy + radius * y0, cz + radius * zSin * r0)
                        .method_22913(u, v0).method_1344();

                // Vertex B (Top ring) - Swapped Y and Z parameters
                bufferBuilder.method_22918(matrix, cx + radius * xCos * r1, cy + radius * y1, cz + radius * zSin * r1)
                        .method_22913(u, v1).method_1344();
            }
        }

        // 5. Draw and upload vertices
        tesselator.method_1350();

        // 6. Reset graphics state
        myCustomShader.method_34585();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
    }
    public static void sphereiguess(class_4587 poseStack, class_2960 texture, double x, double y, double z, float size) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        // 1. Fetch Minecraft's master multi-buffer manager pipeline
        class_4597.class_4598 bufferSource = mc.method_22940().method_23000();

        // 2. Open an unlit translucent channel pointing to your texture.
        // Shimmer scans this RenderType stream natively, triggering your .mcmeta bloom!
        class_4588 vertexConsumer = bufferSource.getBuffer(class_1921.method_42600(texture));

        // 3. Manual camera matrix calculations for the WorldRenderEvents.LAST mouse bug
        class_243 camPos = mc.field_1773.method_19418().method_19326();
        float cx = (float) (x - camPos.field_1352);
        float cy = (float) (y - camPos.field_1351);
        float cz = (float) (z - camPos.field_1350);

        class_1159 matrix = poseStack.method_23760().method_23761();

        int slices = 24;
        int stacks = 24;
        float radius = size;

        // 4. Generate the Sphere using the VertexConsumer format
        for (int i = 0; i < stacks; i++) {
            float lat0 = (float) Math.PI * (-0.5f + (float) i / stacks);
            float y0  = (float) Math.sin(lat0);
            float r0  = (float) Math.cos(lat0);

            float lat1 = (float) Math.PI * (-0.5f + (float) (i + 1) / stacks);
            float y1  = (float) Math.sin(lat1);
            float r1  = (float) Math.cos(lat1);

            for (int j = 0; j <= slices; j++) {
                float lng = (float) (2.0 * Math.PI * (float) j / slices);
                float xCos = (float) Math.cos(lng);
                float zSin = (float) Math.sin(lng);

                float u = (float) j / slices;
                float v0 = (float) i / stacks;
                float v1 = (float) (i + 1) / stacks;

                // --- Vertex A (Bottom ring) ---
                float localXA = radius * xCos * r0;
                float localYA = radius * y0;
                float localZA = radius * zSin * r0;

                vertexConsumer.method_22918(matrix, cx + localXA, cy + localYA, cz + localZA)
                        .method_1336(255, 255, 255, 255)
                        .method_22913(u, v0)
                        .method_22922(class_4608.field_21444)
                        .method_22916(15728880) // Max lightmap value ensures it is emissive full-bright
                        .method_23763(poseStack.method_23760().method_23762(), localXA, localYA, localZA)
                        .method_1344();

                // --- Vertex B (Top ring) ---
                float localXB = radius * xCos * r1;
                float localYB = radius * y1;
                float localZB = radius * zSin * r1;

                vertexConsumer.method_22918(matrix, cx + localXB, cy + localYB, cz + localZB)
                        .method_1336(255, 255, 255, 255)
                        .method_22913(u, v1)
                        .method_22922(class_4608.field_21444)
                        .method_22916(15728880)
                        .method_23763(poseStack.method_23760().method_23762(), localXB, localYB, localZB)
                        .method_1344();
            }
        }

        // 5. CRITICAL STEP FOR THE .LAST EVENT HANDLER:
        // Force the channel to flush and draw all geometry data packets immediately!
        bufferSource.method_22994(class_1921.method_42600(texture));
    }
    public static void drawSpinSphere(class_4587 poseStack, class_2960 texture, float spin, double x, double y, double z, float radius) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        class_289 tessellator = class_289.method_1348();
        class_287 bufferBuilder = tessellator.method_1349();
        class_1159 matrix = poseStack.method_23760().method_23761();

        // 2. Configure RenderSystem states for 3D blending and depth
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderTexture(0, texture);

        bufferBuilder.method_1328(class_293.class_5596.field_27380, class_290.field_1585);

        int slices = 32;
        int stacks = 32;

        float cx = (float) x + 0.5f;
        float cy = (float) y + 0.5f;
        float cz = (float) z + 0.5f;
        radius = radius / 2;

        for (int i = 0; i < stacks; i++) {
            float lat0 = (float) Math.PI * (-0.5f + (float) i / stacks);
            float y0  = (float) Math.sin(lat0);
            float r0  = (float) Math.cos(lat0);

            float lat1 = (float) Math.PI * (-0.5f + (float) (i + 1) / stacks);
            float y1  = (float) Math.sin(lat1);
            float r1  = (float) Math.cos(lat1);

            for (int j = 0; j <= slices; j++) {
                float lng = (float) (2.0 * Math.PI * (float) j / slices);
                float xCos = (float) Math.cos(lng);
                float zSin = (float) Math.sin(lng);

                float u = ((float) j / slices) + spin;
                float v0 = (float) i / stacks;
                float v1 = (float) (i + 1) / stacks;

                // Vertex A (Bottom ring) - Swapped Y and Z parameters
                bufferBuilder.method_22918(matrix, cx + radius * xCos * r0, cy + radius * y0, cz + radius * zSin * r0)
                        .method_22913(u, v0).method_1344();

                // Vertex B (Top ring) - Swapped Y and Z parameters
                bufferBuilder.method_22918(matrix, cx + radius * xCos * r1, cy + radius * y1, cz + radius * zSin * r1)
                        .method_22913(u, v1).method_1344();
            }
        }

        // 5. Draw and upload vertices
        tessellator.method_1350();

        // 6. Reset graphics state
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    public static class_5944 GLOW_SPHERE_SHADER;
    public static void drawBloomSphere(class_4587 poseStack, class_2960 texture, double x, double y, double z, float radius) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        class_289 tessellator = class_289.method_1348();
        class_287 bufferBuilder = tessellator.method_1349();
        class_1159 matrix = poseStack.method_23760().method_23761();

        // 2. Configure RenderSystem states for 3D blending and depth
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.class_4535.SRC_ALPHA, com.mojang.blaze3d.platform.GlStateManager.class_4534.ONE);
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.setShader(class_757::method_34542);

        class_1921 shimmerType = com.lowdragmc.shimmer.client.ShimmerRenderTypes.emissiveArmor(texture);

        shimmerType.method_23516();

        if (GLOW_SPHERE_SHADER != null) {
            RenderSystem.setShader(() -> GLOW_SPHERE_SHADER);
        } else {
            RenderSystem.setShader(class_757::method_34542); // Safety Fallback
        }

        RenderSystem.setShaderTexture(0, texture);

        bufferBuilder.method_1328(class_293.class_5596.field_27380, class_290.field_1580);

        int slices = 24;
        int stacks = 24;

        float cx = (float) x + 0.5f;
        float cy = (float) y + 0.5f;
        float cz = (float) z + 0.5f;
        radius = radius / 2;

        for (int i = 0; i < stacks; i++) {
            float lat0 = (float) Math.PI * (-0.5f + (float) i / stacks);
            float y0  = (float) Math.sin(lat0);
            float r0  = (float) Math.cos(lat0);

            float lat1 = (float) Math.PI * (-0.5f + (float) (i + 1) / stacks);
            float y1  = (float) Math.sin(lat1);
            float r1  = (float) Math.cos(lat1);

            for (int j = 0; j <= slices; j++) {
                float lng = (float) (2.0 * Math.PI * (float) j / slices);
                float xCos = (float) Math.cos(lng);
                float zSin = (float) Math.sin(lng);

                float u = (float) j / slices;
                float v0 = (float) i / stacks;
                float v1 = (float) (i + 1) / stacks;

                // Vertex A (Bottom ring) - Swapped Y and Z parameters
                bufferBuilder.method_22918(matrix, cx + radius * xCos * r0, cy + radius * y0, cz + radius * zSin * r0)
                        .method_1336(255, 255, 255, 255)
                        .method_22913(u, v0)
                        .method_22917(0, 0)
                        .method_22921(240, 240) // CRITICAL: Sets brightness above Shimmer's minimum threshold threshold
                        .method_22914(0, 1, 0)
                        .method_1344();

                // Vertex B
                bufferBuilder.method_22918(matrix, cx + radius * xCos * r1, cy + radius * y1, cz + radius * zSin * r1)
                        .method_1336(255, 255, 255, 255)
                        .method_22913(u, v1)
                        .method_22917(0, 0)
                        .method_22921(240, 240) // CRITICAL: Sets brightness above Shimmer's minimum threshold threshold
                        .method_22914(0, 1, 0)
                        .method_1344();
            }
        }

        // 5. Draw and upload vertices
        tessellator.method_1350();

        // 6. Reset graphics state
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }


}

