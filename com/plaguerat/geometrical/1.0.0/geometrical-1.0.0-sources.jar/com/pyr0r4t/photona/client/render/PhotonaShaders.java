package com.pyr0r4t.photona.client.render;

import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_5944;
import java.io.IOException;

public class PhotonaShaders {
    // This will hold the compiled instance pointer for your Tessellator rendering code
    private static class_5944 sphereShader;

    public static void register() {
        CoreShaderRegistrationCallback.EVENT.register(context -> {
            try {
                // Tells the engine to combine your json, vsh, and fsh tracks using the POSITION_TEX template format
                context.register(
                        new class_2960("photona", "shield"),
                        class_290.field_20887, // <-- CHANGE THIS PARAMETER
                        shaderInstance -> sphereShader = shaderInstance
                );
            } catch (IOException e) {
                System.err.println("Failed to compile custom photona shader code map!");
                e.printStackTrace();
            }
        });
    }

    public static class_5944 getSphereShader() {
        return sphereShader;
    }
}