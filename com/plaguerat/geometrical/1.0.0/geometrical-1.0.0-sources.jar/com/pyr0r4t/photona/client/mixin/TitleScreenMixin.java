package com.pyr0r4t.photona.client.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {

    // Define the path to your Blockbench title image
    private static final class_2960 CUSTOM_TITLE_TEXTURE =
            new class_2960("photona", "textures/gui/minecraft_title.png");

    protected TitleScreenMixin(class_2561 component) {
        super(component);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void drawBlockbenchTitle(class_4587 poseStack, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        // Setup texture states
        RenderSystem.setShaderTexture(0, CUSTOM_TITLE_TEXTURE);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

        // Configuration dimensions (Change to match your exported image dimensions)
        int imageWidth = 1008;
        int imageHeight = 240;

        // Position math: Center horizontally, place near the top
        int xPos = (this.field_22789 - imageWidth) / 2;
        int yPos = 30;

        // Render the image onto the menu screen
        class_332.method_25290(poseStack, xPos, yPos, 0, 0, imageWidth, imageHeight, imageWidth, imageHeight);
    }
}
