package com.pyr0r4t.photona.registry;

import net.minecraft.class_2323;

public class EPicDoor extends class_2323 {
    public EPicDoor(class_2251 props) {
        super(props);
    }
}
