package com.pyr0r4t.photona.client.mixin;
import net.minecraft.class_442;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_442.class)
public class FinallyPutToUseMixin {

	@Redirect(
			method = "<init>(Z)V",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/util/RandomSource;nextFloat()F"
			)
	)
	private float JackPot(class_5819 instance) {
		return 0.0f;
	}
}