package com.pyr0r4t.photona.registry;

import java.util.ArrayList;
import java.util.List;

public class IHoldTrash {
     public static ArrayList<Integer> ope = new ArrayList<>(List.of(24, -59, 8));
     public static int opecount = 0;

    public void addItem(Integer item) {
        ope.add(item);
    }

    public static void incrementOpeCount() {
        opecount +=3;
    }

    public static Integer getItemX(Integer opecount) {
        return ope.get(opecount);
    }
    public static Integer getItemY(Integer opecount) {
        return ope.get(opecount+1);
    }
    public static Integer getItemZ(Integer opecount) {
        return ope.get(opecount+2);
    }
}
