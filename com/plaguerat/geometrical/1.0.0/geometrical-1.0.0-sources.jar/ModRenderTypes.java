/*package com.pyr0r4t.photona.client.registry;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import java.util.function.Function;
import net.minecraft.Util;

public class ModRenderTypes extends RenderType {
    // Unused constructor required to satisfy Java compilation extensions
    public ModRenderTypes(String name, VertexFormat format, VertexFormat.Mode mode, int bufferSize, boolean affectsCrumbling, boolean sortOnUpload, Runnable setupState, Runnable clearState) {
        super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setupState, clearState);
    }

    // A memoized function ensures we don't recreate the composite state needlessly
    public static final Function<ResourceLocation, RenderType> MAGMA_BLOOM = Util.memoize(texture -> {
        RenderType.CompositeState compositeState = RenderType.CompositeState.builder()
                // Bind our custom Core Shader instance
                .setShaderState(new ShaderStateShard(() -> ModShaders.MAGMA_BLOOM_SHADER))
                // Bind the block texture dynamically
                .setTextureState(new TextureStateShard(texture, false, false))
                // Enable transparency alpha blending so our bloom post-effect reads it clearly
                .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
                // Default depth and lightmap settings for blocks
                .setDepthTestState(LEQUAL_DEPTH_TEST)
                .setLightmapState(LIGHTMAP)
                .createCompositeState(true);

        return new RenderType.CompositeRenderType(
                "magma_bloom",
                DefaultVertexFormat.BLOCK,
                VertexFormat.Mode.QUADS,
                2097152,
                true,
                true,
                compositeState
        );
    });
}*/
