#version 150

#moj_import <fog.glsl>

uniform vec4 ColorModulator;
uniform vec4 FogColor;

in float vertexDistance;
in vec2 texCoord0;
in vec4 vertexColor; // Now matching the VSH output layer
in vec3 ViewNormal;
in vec3 ViewDir;

out vec4 fragColor;

float FresnelEffect(vec3 normal, vec3 viewDir, float power) {
    float cosTheta = clamp(dot(normal, viewDir), 0.0, 1.0);
    return pow(1.0 - cosTheta, power);
}

void main() {
    float fresnelValue = FresnelEffect(normalize(ViewNormal), normalize(ViewDir), 3.0);

    // Create a pulsing glowing cyan shield border base
    vec4 baseColor = vec4(0.0, 0.6, 1.0, 0.4);
    baseColor.a *= fresnelValue;

    // Combine with the master modulator and your incoming vertex color channel data
    vec4 finalColor = baseColor * vertexColor * ColorModulator;

    fragColor = linear_fog(finalColor, vertexDistance, 0.0, 100.0, FogColor);
}
