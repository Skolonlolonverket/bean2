#version 150

uniform sampler2D Sampler0;
in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor;

    if (color.a < 0.1) discard;

    // --- The Alchemist's Detection ---
    // Magma textures heavily feature distinct, intense reds and oranges.
    // We check if the red channel is dominant and bright to isolate it.
    bool isMagma = (color.r > 0.6 && color.g < 0.4 && color.b < 0.2);

    if (isMagma) {
        // We encode a secret signature into the Alpha channel (e.g., 0.99)
        // This tells our post-processing shader: "Melt this pixel!"
        fragColor = vec4(color.rgb, 0.99);
    } else {
        fragColor = color;
    }
}
