#version 150

in vec2 texCoord;
uniform sampler2D Sampler0;

out vec4 fragColor;

void main() {
    // 1. Read the base block texture color maps
    vec4 texColor = texture(Sampler0, texCoord);

    // 2. Compute screen-space soft glow falloff
    // Calculate how far the fragment pixel sits from the vertical texture poles
    float distToCenter = length(texCoord - vec2(0.5));

    // Smoothly step the opacity out near the edge of the geometry shell
    float glowAlpha = smoothstep(0.5, 0.2, distToCenter);

    // 3. Define the bright neon style color palette vector
    vec3 baseColor = vec3(1.0, 0.95, 0.55); // Pale neon yellow sun color

    // 4. Force color compounding
    fragColor = vec4(baseColor * (glowAlpha + 0.3), glowAlpha);
}