#version 150

uniform sampler2D DiffuseSampler;
in vec2 texCoord;
out vec4 fragColor;

uniform vec2 InSize; // Screen resolution

void main() {
    vec4 centerColor = texture(DiffuseSampler, texCoord);
    vec3 bloomAccumulation = vec3(0.0);
    float totalWeight = 0.0;

    // The radius of our artistic glow (Adjust to make the bloom larger)
    int radius = 6;
    vec2 texelSize = 1.0 / InSize;

    // Scan the neighboring cubes
    for (int x = -radius; x <= radius; x++) {
        for (int y = -radius; y <= radius; y++) {
            vec2 offset = vec2(float(x), float(y)) * texelSize;
            vec4 neighbor = texture(DiffuseSampler, texCoord + offset);

            // If the neighbor is a marked Magma pixel...
            if (neighbor.a > 0.98 && neighbor.a < 1.0) {
                // Determine weight based on distance (closer = stronger glow)
                float dist = length(vec2(x, y));
                float weight = max(0.0, float(radius) - dist);

                // Add the neighbor's fiery blood to the glow
                bloomAccumulation += neighbor.rgb * weight;
                totalWeight += weight;
            }
        }
    }

    // Blend the original screen color with the accumulated glow
    if (totalWeight > 0.0) {
        vec3 finalGlow = (bloomAccumulation / totalWeight) * 0.5; // Glow intensity
        fragColor = vec4(centerColor.rgb + finalGlow, centerColor.a);
    } else {
        fragColor = centerColor;
    }
}
