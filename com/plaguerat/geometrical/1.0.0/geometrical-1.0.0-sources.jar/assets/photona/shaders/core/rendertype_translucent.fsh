#version 150

// --- Paste Perlin/Simplex Noise Code Here ---
vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec2 mod289(vec2 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec3 permute(vec3 x) { return mod289(((x*34.0)+1.0)*x); }

float snoise(vec2 v) {
    const vec4 C = vec4(0.211324865405187, 0.366025403784439, -0.577350269189626, 0.024390243902439);
    vec2 i  = floor(v + dot(v, C.yy) );
    vec2 x0 = v -   i + dot(i, C.xx);
    vec2 i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
    vec4 x12 = x0.xyxy + C.xxzz;
    x12.xy -= i1;
    i = mod289(i);
    vec3 p = permute( permute( i.y + vec3(0.0, i1.y, 1.0 )) + i.x + vec3(0.0, i1.x, 1.0 ));
    vec3 m = max(0.5 - vec3(dot(x0,x0), dot(x12.xy,x12.xy), dot(x12.zw,x12.zw)), 0.0);
    m = m*m ; m = m*m ;
    vec3 x = 2.0 * fract(p * C.www) - 1.0;
    vec3 h = abs(x) - 0.5;
    vec3 ox = floor(x + 0.5);
    vec3 a0 = x - ox;
    m *= 1.79284291400159 - 0.85373472095314 * ( a0*a0 + h*h );
    vec3 g;
    g.x  = a0.x  * x0.x  + h.x  * x0.y;
    g.yz = a0.yz * x12.xz + h.yz * x12.yw;
    return 130.0 * dot(m, g);
}

in vec2 texCoord0; // Input from vanilla vertex shader
out vec4 fragColor;

void main() {
    // 1. Get the original vanilla texture color
    vec4 color = texture(Sampler0, texCoord0);

    // 2. Generate noise (scaled so it isn't too small)
    float noise = snoise(texCoord0 * 32.0);

    // 3. Map noise from (-1 to 1) to a positive range (0.8 to 1.0) for a subtle effect
    float noiseModifier = 0.9 + (noise * 0.1);

    // 4. Multiply original color by the noise
    fragColor = vec4(color.rgb * noiseModifier, color.a);
    fragColor = vec4(1.0f, 0.0f, 0.0f, 1.0f);
}