#version 150

#moj_import <fog.glsl>

// Explicitly link to Minecraft's POSITION_COLOR_TEX engine slots
in vec3 Position;
in vec4 Color;
in vec2 UV0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec2 texCoord0;
out vec4 vertexColor;
out vec3 ViewNormal;
out vec3 ViewDir;

void main() {
    vec4 viewPos = ModelViewMat * vec4(Position, 1.0);
    gl_Position = ProjMat * viewPos;

    // Set vectors for your Fresnel math calculations
    ViewDir = normalize(viewPos.xyz);
    ViewNormal = normalize(mat3(ModelViewMat) * normalize(Position));

    // Pass information down to the fragment shader
    vertexDistance = fog_distance(viewPos.xyz, FogShape);
    texCoord0 = UV0;
    vertexColor = Color;
}
