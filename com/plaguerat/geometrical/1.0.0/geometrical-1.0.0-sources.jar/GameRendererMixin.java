/*package com.pyr0r4t.photona.client.mixin;

import com.pyr0r4t.photona.client.registry.ModShaders;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.client.renderer.ShaderInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.IOException;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "reloadShaders", at = @At("TAIL"))
    private void registerModShaders(ResourceManager manager, CallbackInfo ci) {
        try {
            // Supply the VertexFormat positional and texture elements (POSITION_COLOR_TEX_LIGHTMAP)
            ModShaders.MAGMA_BLOOM_SHADER = new ShaderInstance(
                    manager,
                    "photona:rendertype_magma_bloom",
                ://minecraft.com.mojang.blaze3d.vertex.DefaultVertexFormat.BLOCK
            );
        } catch (IOException e) {
            throw new RuntimeException("Could not load custom magma bloom shader!", e);
        }
    }
}*/

